Clean journal repository snapshot for ISRS-S-C-L held-out GNPy validation paper.
